package com.company;

import java.util.ArrayList;

public class Empresa {
    private String nombre;
    private ArrayList<Pizza> pizza = new ArrayList<>();

    public Empresa(){
        this.nombre = nombre;
        this.pizza = new ArrayList<>();
    }

    public void agregar(Pizza s){
        pizza.add(s);
    }

    public void mostrarPizza(){
        for (Pizza pi:pizza) {
            System.out.println(pi.getNombre()+" --> Precio: "+pi.calcularPrecio());
        }
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public ArrayList<Pizza> getPizza() {
        return pizza;
    }

    public void setPizza(ArrayList<Pizza> pizza) {
        this.pizza = pizza;
    }
}