package com.company;

import java.util.ArrayList;

public class Combo extends Pizza{
    private ArrayList<Pizza> pizza;

    public Combo(){
        this.pizza = new ArrayList<>();
    }

    public ArrayList<Pizza> getPizza() {
        return pizza;
    }

    public void setPizza(ArrayList<Pizza> pizza) {
        this.pizza = pizza;
    }

    public void agregar(Pizza s){
        pizza.add(s);
    }


    @Override
    public double calcularPrecio() {
        double total = 0;
        for (Pizza p:pizza) {
            total += p.calcularPrecio();
        }
        return total = total/ pizza.size();
    }


}