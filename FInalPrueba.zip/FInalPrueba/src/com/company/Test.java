package com.company;

public class Test {
    public static void main(String[] args) {
        //Creo un servicio simple
        Pizza pizza1 = PizzaFactory.getInstance().crearPizza("Simple");
        //Cargo datos del servicio creado
        pizza1.setNombre("Pizza de muzzarella chica");
        pizza1.setDescripcion("Muzzarella y salsa");
        ((Simple)pizza1).setPrecio(700);
        Pizza pizza2 = PizzaFactory.getInstance().crearPizza("Simple");
        pizza2.setNombre("Pizza de especial chica");
        pizza2.setDescripcion("Jamon, morron y salsa");
        ((Simple)pizza2).setPrecio(850);
        Pizza pizza3 = PizzaFactory.getInstance().crearPizza("Simple");
        pizza3.setNombre("Pizza de anana chica");
        pizza3.setDescripcion("Anana y salsa");
        ((Simple)pizza3).setPrecio(950);
        //Creo un combo de pizzas
        Pizza combo = PizzaFactory.getInstance().crearPizza("Combo");
        //Cargo los precios de las pizzas a la pizza combo
        combo.setNombre("Pizza combianda loca");
        combo.setDescripcion("Mitad especial y mitad anana");
        ((com.company.Combo)combo).agregar(pizza2);
        ((com.company.Combo)combo).agregar(pizza3);
        //Creo la empresa
        Empresa empresa = new Empresa();
        empresa.setNombre("Examen final POO");
        //Agrego los servicios para validar condiciones de calcularPrecio
        empresa.agregar(pizza1);
        empresa.agregar(pizza2);
        empresa.agregar(pizza3);
        empresa.agregar(combo);
        empresa.mostrarPizza();
    }
}