package com.company;

public class Simple extends Pizza{
    private double precio;
    private boolean esGrande;

    public boolean isEsGrande() {
        return esGrande;
    }

    public void setEsGrande(boolean esGrande) {
        this.esGrande = esGrande;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    @Override
    public double calcularPrecio() {
        if (isEsGrande()== true){
            return precio*2;
        }
        return precio;
    }
}
